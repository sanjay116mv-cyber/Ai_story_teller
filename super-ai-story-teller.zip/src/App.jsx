import React, { useState } from "react";

const genres = ["Adventure", "Sci-Fi", "Fantasy", "Mystery", "Horror"];

export default function App() {
  const [genre, setGenre] = useState("Adventure");
  const [character, setCharacter] = useState("");
  const [setting, setSetting] = useState("");
  const [length, setLength] = useState("medium");
  const [story, setStory] = useState("");
  const [loading, setLoading] = useState(false);

  const speak = (text) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "en-US";
    window.speechSynthesis.speak(utterance);
  };

  const generatePrompt = () => {
    return \`Write a \${length} \${genre} story about a character named "\${character}" in a setting of "\${setting}".\`;
  };

  const getStory = async () => {
    setLoading(true);
    setStory("");
    const prompt = generatePrompt();
    const response = await fetch("https://api.deepseek.com/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": "Bearer sk-e45d8840e104499dbeffd45657302d37",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "deepseek-chat",
        messages: [{ role: "user", content: prompt }],
      }),
    });

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    setStory(content || "No story returned.");
    speak(content);
    setLoading(false);
  };

  return (
    <div className="p-6 min-h-screen bg-gradient-to-b from-gray-900 to-black text-white space-y-6">
      <h1 className="text-4xl font-bold text-center">Super AI Story Teller</h1>

      <div className="space-y-4 max-w-xl mx-auto">
        <select className="w-full p-2 rounded" value={genre} onChange={(e) => setGenre(e.target.value)}>
          {genres.map((g) => (
            <option key={g} value={g}>{g}</option>
          ))}
        </select>

        <input className="w-full p-2 rounded" placeholder="Character (e.g., brave fox)" value={character} onChange={(e) => setCharacter(e.target.value)} />

        <input className="w-full p-2 rounded" placeholder="Setting (e.g., enchanted forest)" value={setting} onChange={(e) => setSetting(e.target.value)} />

        <select className="w-full p-2 rounded" value={length} onChange={(e) => setLength(e.target.value)}>
          <option value="short">Short</option>
          <option value="medium">Medium</option>
          <option value="long">Long</option>
        </select>

        <button className="w-full bg-purple-600 p-3 rounded font-bold hover:bg-purple-700 transition" onClick={getStory}>
          {loading ? "Telling story..." : "Tell Story"}
        </button>
      </div>

      {story && (
        <div className="mt-8 p-4 bg-gray-800 rounded-lg max-w-3xl mx-auto whitespace-pre-line">
          <h2 className="text-xl font-semibold mb-2">Story:</h2>
          <p>{story}</p>
        </div>
      )}
    </div>
  );
}